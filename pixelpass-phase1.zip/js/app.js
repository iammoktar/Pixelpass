/* PixelPass Studio - shared site behaviour */
(function(){
var b=document.getElementById("menu"),n=document.getElementById("nav");
if(b&&n){b.addEventListener("click",function(){var o=n.classList.toggle("open");b.setAttribute("aria-expanded",o?"true":"false")});
n.addEventListener("click",function(e){if(e.target.closest("a")){n.classList.remove("open");b.setAttribute("aria-expanded","false")}})}
var p=location.pathname.split("/").pop()||"index.html";
document.querySelectorAll(".nav a.link").forEach(function(a){var h=a.getAttribute("href");if(h===p&&h.indexOf("#")<0)a.setAttribute("aria-current","page")});
var y=document.getElementById("year");if(y)y.textContent=new Date().getFullYear();
})();
